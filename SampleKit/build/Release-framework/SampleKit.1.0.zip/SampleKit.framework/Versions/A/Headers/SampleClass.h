//
//  SampleClass.h
//  MacOSFramework
//
//  Created by Hiroshi Hashiguchi on 10/11/05.
//  Copyright 2010 . All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SampleClass : NSObject {

}

- (NSString*)stringHello;

@end
